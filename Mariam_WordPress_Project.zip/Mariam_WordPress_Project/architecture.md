WordPress Cloud Infrastructure Architecture

Overview

This project demonstrates a resilient, containerized WordPress deployment on AWS. It uses a decoupled storage approach to ensure data persistence and automated off-site backups.


COMPONENT
* **Compute:** AWS EC2 (t3.micro) running Ubuntu 24.04.
* **Orchestration:** Docker Compose manages two containers:
    * **WordPress:** The web frontend (latest image).
    * **MySQL 8.0:** The database backend.
* **Storage:** * An 8GB **EBS Volume** is mounted at `/mnt/mysql-data`. 
    * Docker volumes are mapped to this mount point to ensure database records survive instance reboots or container recreation.
* **Backup:** A Bash script (`backup.sh`) utilizes the **AWS CLI v2** to perform a `sync` operation, moving local database files and configuration to a versioned **S3 Bucket** (`wordpress-backup-mariam-2026`).

Design Decisions & Trade-offs
* **EBS vs. Local Storage:** Chose a dedicated EBS volume over the root partition to separate the OS from the data, allowing for easier volume snapshots and scaling.
* **S3 for Backups:** Chose S3 for its 99.999999999% durability, ensuring that even if the entire EC2 instance is terminated, the website data is safe.
* **Docker Compose:** Used for simplicity and "Infrastructure as Code" principles, making the environment easily reproducible.