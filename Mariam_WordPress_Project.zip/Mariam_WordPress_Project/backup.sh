#!/bin/bash
# Timestamp for unique backup naming
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/mnt/mysql-data/wordpress-project"

echo "Starting backup for $TIMESTAMP..."

# Sync local project folder to S3
# We use 'sync' to ensure all project files and the .sql dump are uploaded
aws s3 sync $BACKUP_DIR s3://wordpress-backup-mariam-2026/backups/$TIMESTAMP

echo "Backup completed successfully!"